damei库是一个深度学习库，包含了常用函数及控制台。

# 1.安装
```python
pip install git+https://github.com/zhangzhengde0225/damei.git  # 从github安装
pip install damei -i https://pypi.Python.org/simple  # 从pypi安装
```

# 2.使用
```python
import damei as dm

```