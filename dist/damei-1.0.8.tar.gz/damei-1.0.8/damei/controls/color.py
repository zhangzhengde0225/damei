class ColorControl(object):
	def __init__(self):
		self.a = 'color'

	def r(self):
		print('fuck mei')
