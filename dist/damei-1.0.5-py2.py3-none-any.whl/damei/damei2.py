def main():
	print('xx')


if __name__ == '__main__':
	main()
