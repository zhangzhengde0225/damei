__name__ = "damei"
__version__ = '1.0.8'

from damei.functions import general, torch_utils
from damei.controls.color import ColorControl
from damei.post import post
